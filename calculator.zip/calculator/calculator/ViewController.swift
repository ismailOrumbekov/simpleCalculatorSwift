//
//  ViewController.swift
//  calculator
//
//  Created by Ismail Orumbekov on 03.06.2023.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var numberLabel: UILabel!
    var numberString = ""
    var calculatingNumber : Double = 0
    var lastCalculation = ""
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func numberButtonPressed(_ sender: UIButton) {
        let type = sender.currentTitle!
        if type == "." && numberString.isEmpty{
            numberString = "0"
        }
        numberString += "\(String(describing: type))"
        numberLabel.text = numberString
        
    }
    
    
    @IBAction func calculateButtonPressed(_ sender: UIButton) {
        calculating()
        lastCalculation = sender.currentTitle!
    }
    
    @IBAction func clearButtonPressed(_ sender: UIButton) {
        numberString = ""
        numberLabel.text = "0"
        calculatingNumber = 0
        lastCalculation = ""
    }
    
    @IBAction func oneClickButtonPressed(_ sender: UIButton) {
        calculating()
        switch sender.currentTitle!{
        case "%":
            calculatingNumber /= 100
            lastCalculation = "%"
        case "+/-":
            lastCalculation = "+/-"
            calculatingNumber *= -1
        default:
            print("default")
        }
        numberLabel.text = "\(calculatingNumber)"
        numberString = ""
        lastCalculation = sender.currentTitle!
    }
    func calculating(){
        let number = Double(numberLabel.text!)!
        switch lastCalculation{
        case "+":
            calculatingNumber += number
        case "-":
            calculatingNumber -= number
        case "×":
            calculatingNumber *= number
        case "÷":
            calculatingNumber /= number
        case "=":
            lastCalculation = ""
        default:
            calculatingNumber = number
        }
        numberLabel.text = "\(calculatingNumber)"
        numberString = ""
    }
    
    
    
}

